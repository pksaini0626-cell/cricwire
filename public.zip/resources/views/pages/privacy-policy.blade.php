@include('legal.privacy')
