<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['activeTab' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['activeTab' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $currentRoute = request()->route()?->getName();
    $currentPath = request()->path();
    
    // Auto detect active tab if not explicitly passed
    $active = $activeTab ?: match(true) {
        $currentRoute === 'more' || $currentPath === 'more' || $currentPath === 'profile' => 'more',
        $currentRoute === 'polls' || $currentPath === 'polls' => 'polls',
        $currentRoute === 'news.index' || str_starts_with($currentPath, 'cricket-news') => 'news',
        $currentRoute === 'schedule' || str_starts_with($currentPath, 'cricket-schedule') => 'schedule',
        default => 'live',
    };
?>

<nav class="md:hidden lg:hidden fixed bottom-3 left-4 right-4 z-50 max-w-md mx-auto rounded-2xl bg-slate-900/90 backdrop-blur-xl border border-white/10 shadow-2xl overflow-hidden">
    <div class="grid grid-cols-5 h-14 items-center">
        <!-- Live -->
        <a href="<?php echo e(url('/')); ?>" wire:navigate class="flex flex-col items-center justify-center transition-all group <?php echo e($active === 'live' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'); ?>">
            <span class="text-base group-hover:scale-110 transition-transform <?php echo e($active === 'live' ? 'drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : ''); ?>">
                ⚡
            </span>
            <span class="text-[10px] <?php echo e($active === 'live' ? 'font-black uppercase tracking-wider text-neon-gold' : 'font-medium tracking-tight'); ?> mt-0.5">Live</span>
        </a>

        <!-- Schedule -->
        <a href="<?php echo e(route('schedule')); ?>" wire:navigate class="flex flex-col items-center justify-center transition-all group <?php echo e($active === 'schedule' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'); ?>">
            <span class="text-base group-hover:scale-110 transition-transform <?php echo e($active === 'schedule' ? 'drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : ''); ?>">
                📅
            </span>
            <span class="text-[10px] <?php echo e($active === 'schedule' ? 'font-black uppercase tracking-wider text-neon-gold' : 'font-medium tracking-tight'); ?> mt-0.5">Schedule</span>
        </a>

        <!-- News -->
        <a href="<?php echo e(route('news.index')); ?>" wire:navigate class="flex flex-col items-center justify-center transition-all group <?php echo e($active === 'news' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'); ?>">
            <span class="text-base group-hover:scale-110 transition-transform <?php echo e($active === 'news' ? 'drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : ''); ?>">
                📰
            </span>
            <span class="text-[10px] <?php echo e($active === 'news' ? 'font-black uppercase tracking-wider text-neon-gold' : 'font-medium tracking-tight'); ?> mt-0.5">News</span>
        </a>

        <!-- Polls -->
        <a href="<?php echo e(route('polls')); ?>" wire:navigate class="flex flex-col items-center justify-center transition-all group <?php echo e($active === 'polls' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'); ?>">
            <span class="text-base group-hover:scale-110 transition-transform <?php echo e($active === 'polls' ? 'drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : ''); ?>">
                🗳️
            </span>
            <span class="text-[10px] <?php echo e($active === 'polls' ? 'font-black uppercase tracking-wider text-neon-gold' : 'font-medium tracking-tight'); ?> mt-0.5">Polls</span>
        </a>

        <!-- More -->
        <a href="<?php echo e(route('more')); ?>" wire:navigate class="flex flex-col items-center justify-center transition-all group <?php echo e($active === 'more' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'); ?>">
            <span class="text-base group-hover:scale-110 transition-transform <?php echo e($active === 'more' ? 'drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : ''); ?>">
                ⚙️
            </span>
            <span class="text-[10px] <?php echo e($active === 'more' ? 'font-black uppercase tracking-wider text-neon-gold' : 'font-medium tracking-tight'); ?> mt-0.5">More</span>
        </a>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\cricwire\resources\views/components/bottom-nav.blade.php ENDPATH**/ ?>