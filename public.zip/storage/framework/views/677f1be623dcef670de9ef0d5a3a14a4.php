<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="dark bg-slate-950">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        <title><?php echo e($title ?? 'CricWire - Live Cricket Scores, Fast Ball-by-Ball Live Line'); ?></title>

        <!-- CricWire Favicons & PWA -->
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('icons/cricwire_favicons/favicon.ico')); ?>">
        <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('icons/cricwire_favicons/favicon-32x32.png')); ?>">
        <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('icons/cricwire_favicons/favicon-16x16.png')); ?>">
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('icons/cricwire_favicons/apple-touch-icon.png')); ?>">
        <link rel="manifest" href="/manifest.json">
        <meta name="theme-color" content="#020617">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">

        <!-- Tailwind CSS CDN fallback & Vite assets -->
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php else: ?>
            <script src="https://cdn.tailwindcss.com"></script>
            <script>
                tailwind.config = {
                    darkMode: 'class',
                    theme: {
                        extend: {
                            colors: {
                                brand: {
                                    primary: '#0ea5e9',
                                    accent: '#ef4444',
                                    gold: '#eab308',
                                }
                            }
                        }
                    }
                }
            </script>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    </head>
    <style>
    /* Livewire SPA Top Navigation Bar */
    [wire\:navigate-progress] {
        background-color: #f59e0b !important; /* Neon Amber */
        height: 3px !important;
        box-shadow: 0 0 10px #f59e0b, 0 0 5px #10b981;
    }
</style>
    <body class="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-amber-500 selection:text-black">
        <!-- Global SPA Navigation & Request Loader -->
        <?php if (isset($component)) { $__componentOriginalee410a978f4e4eb81bd48880bd2292ce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee410a978f4e4eb81bd48880bd2292ce = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cricket-loader','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('cricket-loader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee410a978f4e4eb81bd48880bd2292ce)): ?>
<?php $attributes = $__attributesOriginalee410a978f4e4eb81bd48880bd2292ce; ?>
<?php unset($__attributesOriginalee410a978f4e4eb81bd48880bd2292ce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee410a978f4e4eb81bd48880bd2292ce)): ?>
<?php $component = $__componentOriginalee410a978f4e4eb81bd48880bd2292ce; ?>
<?php unset($__componentOriginalee410a978f4e4eb81bd48880bd2292ce); ?>
<?php endif; ?>

        <div class="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-amber-500 selection:text-black flex flex-col">
            <?php echo e($slot ?? ''); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


        <!-- PWA Service Worker Registration -->
        <script>
            if ('serviceWorker' in navigator) {
                window.addEventListener('load', () => {
                    navigator.serviceWorker.register('/sw.js')
                        .then((reg) => {
                            console.log('Cricwire SW registered:', reg.scope);
                        })
                        .catch((err) => {
                            console.error('Cricwire SW registration failed:', err);
                        });
                });
            }
        </script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\cricwire\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>